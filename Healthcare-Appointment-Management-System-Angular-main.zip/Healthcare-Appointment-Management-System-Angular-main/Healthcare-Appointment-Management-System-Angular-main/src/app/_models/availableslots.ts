export interface AvailableSlots {
    doctorId: number
    doctorName: string
    date: Date
    startTime: string
    endTime: string
    message: string
}