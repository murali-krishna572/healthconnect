export interface Availability {
    date: Date
    startTime: string
    endTime: string
    message: string
}