export interface Prescriptions {
    success: boolean;
    appointmentId: number;
    prescription: string;
    notes: string;
    message: string;
}  