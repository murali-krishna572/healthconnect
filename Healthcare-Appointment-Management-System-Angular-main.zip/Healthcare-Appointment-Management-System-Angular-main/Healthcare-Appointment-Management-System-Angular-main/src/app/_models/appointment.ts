export interface Appointment {
    appointmentId: number
    date: Date
    startTime: string
    doctorName: string
    message: string
}