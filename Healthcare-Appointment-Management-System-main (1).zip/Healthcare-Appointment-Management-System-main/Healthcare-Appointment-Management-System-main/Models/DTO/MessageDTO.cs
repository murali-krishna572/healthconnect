﻿namespace AppointmentManagement.Models.DTO
{
    public class MessageDTO
    {
        public string Message { get; set; }
    }
}
